package FList;

import LApp.Entity;

public class MyNode {
	
	boolean delete_flag;
	
    public MyNode(Entity elem) {
        this.delete_flag = false;
    }
}
