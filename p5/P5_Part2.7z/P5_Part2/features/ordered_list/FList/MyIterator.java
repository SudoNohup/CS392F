package FList;

import java.util.Iterator;
import LApp.Entity;

public class MyIterator implements Iterator {

    public MyNode currnode() {
    	return this.current;
    }

}
